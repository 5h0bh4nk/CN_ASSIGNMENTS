#include <bits/stdc++.h>
using namespace std;

int main(){
    int num1,num2;
    scanf("%d",&num1);
    scanf("%d", &num2);
    printf("%d\n",num1+num2);
    scanf("%d", &num1);
    scanf("%d", &num2);
    printf("%d\n",num1 - num2);
    scanf("%d", &num1);
    scanf("%d", &num2);
    printf("%d\n", num1 * num2);
}