#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include  <poll.h>
#include <fcntl.h>

// int ss1

int main(int argc,char**argv){
    int listenfd,connfd;
    socklen_t client;
    struct sockaddr_in server_addr,client_addr;

    // Creating socket file descriptor
    listenfd=socket(AF_INET,SOCK_STREAM,0);
    bzero(&server_addr,sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=htonl(INADDR_ANY);
    server_addr.sin_port=htons(atoi(argv[1]));
    bind(listenfd,(struct sockaddr*)&server_addr,sizeof(server_addr));
    listen(listenfd,5);
    client=sizeof(client_addr);
    connfd=accept(listenfd,(struct sockaddr*)&client_addr,&client);
    char buffer[10000];

    // connect to special service 1
    int sockfd1;
    struct sockaddr_in addr1, addr2;
    sockfd1=socket(AF_INET,SOCK_STREAM,0);
    bzero(&addr1,sizeof(addr1));
    addr1.sin_family=AF_INET;
    addr1.sin_addr.s_addr=htonl(INADDR_ANY);
    addr1.sin_port=htons(atoi("8081"));
    inet_pton(AF_INET,"8081",&addr1.sin_addr);
    connect(sockfd1,(struct sockaddr*)&addr1,sizeof(addr1));

    // connect to special service 2
    int sockfd2;
    sockfd2=socket(AF_INET,SOCK_STREAM,0);
    bzero(&addr2,sizeof(addr2));
    addr2.sin_family=AF_INET;
    addr2.sin_addr.s_addr=htonl(INADDR_ANY);
    addr2.sin_port=htons(atoi("8082"));
    inet_pton(AF_INET,"8082",&addr2.sin_addr);
    connect(sockfd2,(struct sockaddr*)&addr2,sizeof(addr2));

    int nfds = 2;
    int num_open = 2;
    int len = sizeof(client);
    int nsfd;
    int flag = 0;
    int fds[2] = {sockfd1, sockfd2};

    struct pollfd pfd[2];
    for (int i = 0; i < 2; i++)
    {
        pfd[i].fd = fds[i];
        pfd[i].events = POLLIN;
    }

    int nsfd1 , nsfd2 ;    
    while (1)
    {
        int ret = poll(fds, 2, 200);
        if(ret < 0){
            perror("poll");
            exit(1);
        }
        if(pfd[0].revents & POLLIN){
            int addrlen = sizeof(addr1);
            if((nsfd1 = accept(sockfd1, (struct sockaddr *)&addr1, &addrlen)) == -1){
                perror("accept");
                exit(EXIT_FAILURE);
            }
            printf("Connection accepted from client 1\n");
            // creating thread to receive data from client 1
            pthread_t thread1;
            pthread_create(&thread1, NULL, (void *(*)(void *))connect_s1, (void *)&nsfd1);
            close(nsfd1);
        }
        if(pfd[1].revents & POLLIN){
            int addrlen = sizeof(addr2);
            if((nsfd2 = accept(sockfd2, (struct sockaddr *)&addr2, &addrlen)) == -1){
                perror("accept");
                exit(EXIT_FAILURE);
            }
            printf("Connection accepted from client 2\n");
            // creating thread to receive data from client 2
            pthread_t thread2;
            pthread_create(&thread2, NULL, (void *(*)(void *))connect_s2, (void *)&nfsd2);
            close(nfsd2);
        }
    }

    while(1){
        read(connfd, buffer, 10000);
        if(buffer[0]=='1'){
            buffer[0] = " ";
            write(sockfd1,buffer,10000);
        }
        else if(buffer[0]=='2'){
            buffer[0] = " ";
            write(sockfd2,buffer,10000);
        }
    }
}